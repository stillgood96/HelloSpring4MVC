create view 제품1 as
select `playground`.`productTest`.`pdNum`    AS `pdNum`,
       `playground`.`productTest`.`qunatity` AS `qunatity`,
       `playground`.`productTest`.`company`  AS `company`
from `playground`.`productTest`;

