create view 우수고객 as
select `playground`.`customerTest`.`csid` AS `csid`, `playground`.`customerTest`.`csname` AS `csname`
from `playground`.`customerTest`
where `playground`.`customerTest`.`grd` = 'vip';

