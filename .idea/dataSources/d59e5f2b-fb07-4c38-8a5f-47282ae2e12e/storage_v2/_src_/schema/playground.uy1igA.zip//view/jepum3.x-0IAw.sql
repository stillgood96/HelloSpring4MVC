create view 제품3 as
select `playground`.`productTest`.`pdName`   AS `pdName`,
       `playground`.`productTest`.`qunatity` AS `qunatity`,
       `playground`.`productTest`.`company`  AS `company`
from `playground`.`productTest`;

